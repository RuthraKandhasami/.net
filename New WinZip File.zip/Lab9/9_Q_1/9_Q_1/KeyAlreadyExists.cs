﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_Q_1
{
    class KeyAlreadyExists:Exception
    {
        public KeyAlreadyExists(String message) : base(message)
        {

        }
    }
}
