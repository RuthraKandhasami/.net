﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            Arithmeticoperation.Calculator objcal = new Arithmeticoperation.Calculator();
            double fnum;
            double snum;
            double result;
            double option;
           
            do
            {
                /*Console.WriteLine("enter the first number:");
                fnum = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("enter the second number:");
                snum = Convert.ToDouble(Console.ReadLine());*/
                Console.WriteLine("enter 1 for addition");
                Console.WriteLine("enter 2 for subtraction");
                Console.WriteLine("enter 3 for multiply");
                Console.WriteLine("enter 4 for division");
                Console.WriteLine("enter 5 for modulo");

                Console.WriteLine("Choose the option:");
                option = Convert.ToDouble(Console.ReadLine());
                //calculator
               

                switch (option)
                {
                    case 1:
                        //Addition
                        Console.WriteLine("enter first value: ");
                        fnum = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter second value: ");
                        snum = Convert.ToDouble(Console.ReadLine());
                        result = objcal.Addition(fnum, snum);
                        Console.WriteLine("Addition of two numbers is: " + result);
                        break;

                    case 2:
                        //subtraction
                        Console.WriteLine("enter first value: ");
                        fnum = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter second value: ");
                        snum = Convert.ToDouble(Console.ReadLine());
                        result = objcal.Subtraction(fnum, snum);
                        Console.WriteLine("Subtraction of two numbers is: " + result);
                        break;

                    case 3:
                        //Multiplication
                        Console.WriteLine("enter first value: ");
                        fnum = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter second value: ");
                        snum = Convert.ToDouble(Console.ReadLine());
                        result = objcal.Multiplication(fnum, snum);
                        Console.WriteLine("Multiplication of two numbers is: " + result);
                        break;

                    case 4:
                        //Divison
                        Console.WriteLine("enter first value: ");
                        fnum = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter second value: ");
                        snum = Convert.ToDouble(Console.ReadLine());
                        result = objcal.Division(fnum, snum);
                        Console.WriteLine("Division of two numbers is: " + result);
                        break;

                    case 5:
                        //Modulo
                        Console.WriteLine("enter first value: ");
                        fnum = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter second value: ");
                        snum = Convert.ToDouble(Console.ReadLine());
                        result = objcal.Modulo(fnum, snum);
                        Console.WriteLine("Modulo of two numbers is: " + result);
                        break;

                    case 6:
                        //exit
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("please enter a valid number...");
                        break;
                }

                Console.WriteLine("do you want to continue? press y or else press n");
                option = Convert.ToChar(Console.ReadLine());

            } while (option == 'y');
 
        }
    }
}
