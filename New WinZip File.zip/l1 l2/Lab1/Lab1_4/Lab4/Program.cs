﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            int Rollnumber;
            String Studentname;
            byte Age;
            char Gender;
            DateTime DoB;
            String Address;
            float Percentage;

            Console.WriteLine("____----____Enter student details____---___");
            Console.WriteLine("____________________________________________");
            Console.WriteLine("RollNo");
            Rollnumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("StudentName");
            Studentname = Convert.ToString(Console.ReadLine());
            Console.WriteLine("StudentAge");
            Age = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Gender");
            Gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("DoB");
            DoB = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Address");
            Address = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Percentage");
            Percentage = Convert.ToInt64(Console.ReadLine());

            Console.WriteLine("_______----______------_____");
            Console.WriteLine("Displaying Student Details");
            Console.WriteLine("Student RollNo is " + Rollnumber);
            Console.WriteLine("Student Name is " + Studentname);
            Console.WriteLine("Student Age is " + Age);
            Console.WriteLine("Student Gender is " + Gender);
            Console.WriteLine("Student DateOfBirth is " + DoB);
            Console.WriteLine("Student Address is " + Address);
            Console.WriteLine("Student Percentage is " + Percentage);
        }
    }
}
