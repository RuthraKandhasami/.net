﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            int option;
            char choose;

            do
            {
                Console.WriteLine("enter a number");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        Console.WriteLine("you pressed the number 1");
                        break;
                    case 2:
                        Console.WriteLine("you pressed the number 2");
                        break;
                    case 3:
                        Console.WriteLine("you pressed the number 3");
                        break;
                    case 4:
                        Console.WriteLine("you pressed the number 4");
                        break;
                    case 5:
                        Console.WriteLine("you pressed the number 5");
                        break;
                    default:
                        Console.WriteLine("please press a valid number");
                        break;

                }
                Console.WriteLine("___----------______");
                Console.WriteLine("do you want to continue (y/n)");

                choose = Convert.ToChar(Console.ReadLine());
            } while (choose == 'y');
            //Console.Readkey();
        }
    }
}
