﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3._1
{
    public class Participant
    {
        private int empid;
        private string name;
        private string cname;
        private double fmark;
        private double wbmarks;
        private double dnmarks;
        private double tmarks = 300;
        public double obtmarks;
       
        public float percentage;


        public double Obtmarks
        {
            get
            {
                return obtmarks;


            }
            set
            {
                obtmarks = value;
            }
        }
        public double Percentage
        {
            get
            {
                return percentage;


            }
            set
            {
                percentage = value;

            }
        }
        public Participant()
        {


        }
        public Participant(int empid, string name, string cname, double fmark, double wbmarks, double dnmarks, double obtmarks, double percentage)
        {

        }
        static Participant()
        {
            cname = "Corporate University";
        }
   