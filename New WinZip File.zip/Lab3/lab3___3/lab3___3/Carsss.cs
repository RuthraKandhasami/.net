﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3___3
{
    class Carsss
    {
        Carsss[] objCarsss = new Carsss[2];
        public void AddCar(Carsss objCar)
        {
            objCarsss[ctr++] = objCar;

        }
        public void UpdateCar(Carsss objCar)
        {

        }
        public void DeleteCar(Carsss objCar)
        {

        }
        public Car SearchCar(string make)
        {
            foreach(Carsss objCar in objCarsss)
            {
                if(objCa                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  )
            }
        }
        }
}
