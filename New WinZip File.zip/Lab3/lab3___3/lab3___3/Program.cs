﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3___3
{
   class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("cars portal");
            Console.WriteLine("prees 1 for add car \n press 2 for update car \n press 3 for search car \n press 4 for delete \n press 5 for view \n pree 6 to quit");
            int choice;
            switch(choice)
            {
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;

                case 5:
                    break;
                case 6:
                    break;
                default:
                    break;

            }
            static void AddCar()
            {
                Console.WriteLine("enter car details");
                Console.WriteLine("enter make");
                make = Console.ReadLine();
                model = Console.ReadLine();
                year = Console.ReadLine();
                saleprice = Convert.ToInt32(Console.ReadLine());
                Cars objCar = new Cars { Make = make, Model = model, Year = year, SalePrice = saleprice };
                objCarss
            }
    }
}
