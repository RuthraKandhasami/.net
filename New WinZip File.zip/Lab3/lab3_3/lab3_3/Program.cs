﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3_3
{
    class Program
    {
            static int indx = 0;
            static Cars[] Catelog = new Cars[20];
            string command;
            static void Main(string[] args)
            {
                
                while (command != "6")
                {
                    Console.WriteLine("Enter the number of the command you want: ");
                    Console.WriteLine("1. Add ");
                    Console.WriteLine("2. List ");
                    Console.WriteLine("3. Search");
                  Console.WriteLine("4.modify");
                  Console.WriteLine("5.delete");
                    Console.WriteLine("6. Quit ");
                    command = Console.ReadLine();
                    switch (command)
                    {
                        case "1":
                            {
                                Console.Write("Year: ");
                                string year = Console.ReadLine();
                                Console.Write("Make: ");
                                string make = Console.ReadLine();
                                Console.Write("Model: ");
                                string model = Console.ReadLine();
                                Console.Write("Price: ");
                                string price = Console.ReadLine();
                                Add(year, make, model, Convert.ToInt32(price));
                                break;
                            }
                        case "2":
                            {
                                List();
                                break;
                            }
                        case "3":
                            {

                            
                            Search();
                            break;
                            
                            }
                        case "4":
                            {
                                Modify();
                                break;
                            }
                        case "5":
                            {
                            delete();
                            break;

                            }
                        case "6":
                            break;
                    default:


                    }
                }
            }
            private static void Search(string make)
            {
                for (int i = 0; i <= Catelog.Length - 1; i++)
                {
                    if (Catelog[i].Make.ToLower() == make.ToLower())
                    {
                        Console.Write("{0}\t", Catelog[i].Year);
                        Console.Write("{0}\t", Catelog[i].Make);
                        Console.Write("{0}\t", Catelog[i].Model);
                        Console.Write("{0}", Catelog[i].Price);
                        Console.WriteLine("");
                        break;
                    }
                }
            }
            public static void ListByYear()
            {
                Array.Sort(Catelog, (IComparer)new Cars.SortByYearClass());
                Console.WriteLine("Year    Make    Model   Price");
                Console.WriteLine("=======================================================");
                for (int i = 0; i <= Catelog.Length - 1; i++)
                {
                    if (Catelog[i] != null)
                    {
                        Console.Write("{0}\t", Catelog[i].Year);
                        Console.Write("{0}\t", Catelog[i].Make);
                        Console.Write("{0}\t", Catelog[i].Model);
                        Console.Write("{0}", Catelog[i].Price);
                        Console.WriteLine("");
                    }
                }
            }
            public static void Add(string year, string make, string model, double price)
            {
                Catelog[indx] = new Cars(year, make, model, price);
                indx++;
            }
            public static void List()
            {
                Console.WriteLine("Year    Make    Model   Price");
                Console.WriteLine("=======================================================");
                for (int i = 0; i <= Catelog.Length - 1; i++)
                {
                    if (Catelog[i] != null)
                    {
                        Console.Write("{0}\t", Catelog[i].Year);
                        Console.Write("{0}\t", Catelog[i].Make);
                        Console.Write("{0}\t", Catelog[i].Model);
                        Console.Write("{0}", Catelog[i].Price);
                        Console.WriteLine("");
                    }
                }
            }
            public static void ListByPrice()
            {
                Array.Sort(Catelog);
                Console.WriteLine("Year    Make    Model   Price");
                Console.WriteLine("=======================================================");

                for (int i = 0; i <= Catelog.Length - 1; i++)
                {
                    if (Catelog[i] != null)
                    {
                        Console.Write("{0}\t", Catelog[i].Year);
                        Console.Write("{0}\t", Catelog[i].Make);
                        Console.Write("{0}\t", Catelog[i].Model);
                        Console.Write("{0}", Catelog[i].Price);
                        Console.WriteLine("");
                    }
                }
            }
        }
        public class Cars : IComparable
        {
            public string sortby;
            private string _make;
            private string _model;
            private double _price;
            private string _year;
            public Cars(string year, string make, string model, double price)
            {
                Year = year;
                Make = make;
                Model = model;
                Price = price;
            }
            public string Make
            {
                get
                {
                    return _make;
                }
                set
                {
                    _make = value;
                }
            }
            public string Model
            {
                get
                {
                    return _model;
                }
                set
                {
                    _model = value;
                }
            }
            public double Price
            {
                get
                {
                    return _price;
                }
                set
                {
                    _price = value;
                }
            }
            public string Year
            {
                get
                {
                    return _year;
                }
                set
                {
                    _year = value;
                }
            }
            int IComparable.CompareTo(Object c)
            {
                Cars o = (Cars)c;
                int retval = this.Price.CompareTo(o.Price);
                if (retval != 0)
                {
                    return retval;
                }
                else
                {
                    return this.Price.CompareTo(o.Price);
                }
            }
            public class SortByYearClass : IComparer
            {
                public int Compare(object obj1, object obj2)
                {
                    Cars car1 = (Cars)obj1;
                    Cars car2 = (Cars)obj2;
                    return (String.Compare(car1.Year, car2.Year));
                }
            }
        }
    }

        

