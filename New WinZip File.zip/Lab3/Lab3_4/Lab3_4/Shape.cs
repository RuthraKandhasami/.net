﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    public class Shape
    {
        private void WhoamI()
        {
            Console.WriteLine("I m Shape");
        }
    }
}
