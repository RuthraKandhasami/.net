﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle s;
            s = new Circle();
            s.WhoamI();
            Triangle t;
            t = new Triangle();
            t.WhoamI();
            Console.ReadKey();
        }
    }
}
