﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7__2
{
    class Product
    {
        public int pnumber;
        public string pname;
        public int prate;
        public int pstock;
    }
}
