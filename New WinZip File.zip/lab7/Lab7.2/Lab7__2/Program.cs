﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7__2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Product[] p;
            // Product p1 = new Product();
            ArrayList objAL = new ArrayList();
            int option;
            //add(); Search();
            do
            {
                Console.WriteLine("\n--------------------------\nPress the following Keys to proceed :\n 1-Add product \n 2-Search product " +"\n 3-Delete product\n 4-Save in sorted order 5-Quit");
                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        {
                            add();
                            break;
                        }
                    case 2:
                        {
                            Search();
                            break;
                        }
                    case 3:
                        {
                            Delete();
                            //Console.WriteLine("delete");
                            break;
                        }
                    case 4:
                        {
                            SaveInSorted();
                            break;
                        }

                    case 5:
                        break;
                    default:
                        Console.WriteLine("Please enter valid input");
                        break;

                }
            } while (option != 5);

            //int count;

            void add()
            {
                Console.WriteLine("Enter the number of product u need to enter");
                int numproduct = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < numproduct; i++)
                {
                    Product objProduct = new Product();
                    Console.WriteLine("Enter Product Number : ");
                    objProduct.pnumber = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Product Name : ");
                    objProduct.pname = Console.ReadLine();
                    Console.WriteLine("Enter Product Rating : ");
                    objProduct.prate = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Product Stock : ");
                    objProduct.pstock = Convert.ToInt32(Console.ReadLine());
                    objAL.Add(objProduct);
                    // objal.Add(p1);
                    Console.WriteLine(" -----------Data entered successfully----------");
                }
                //count++;

            }
            void Search()
            {
                int search;
                Console.WriteLine("\n---------------------------------------------\nEnter product number u want to Search");
                search = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < objAL.Count; i++)
                {
                    Product objProduct = objAL[i] as Product;
                    //
                    if (objProduct.pnumber == search)
                    {
                        Console.WriteLine("Ur record is PRESENT\n-----------------------------\n");

                        Console.WriteLine("Product Number :  " + objProduct.pnumber + "\nProduct Name :   " + objProduct.pname + "\nProduct Rating :  " + objProduct.prate + "\nProduct Stock :  " + objProduct.pstock);
                    }

                    else
                    {
                        Console.WriteLine("Ur record is ABSENT");
                    }

                }


            }
            void Delete()
            {
                int check;
                Console.WriteLine("\n---------------------------------------------\nEnter product number u want to delete");
                check = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < objAL.Count; i++)
                {
                    Product objProduct = objAL[i] as Product;
                    //
                    if (objProduct.pnumber == check)
                    {
                        objAL.Remove(objProduct);




                        Console.WriteLine(" -----------Data removed successfully----------");

                    }
                }



            }
            void SaveInSorted()
            {
                /* foreach (var obj in objal)
                 {
                     Console.WriteLine(obj);
                     Console.WriteLine("Product Number :  " + p1.prodno + "\nProduct Name :   " + p1.name + "\nProduct Rating :  " + p1.rate + "\nProduct Stock :  " + p1.stock);
                 }*/

                for (int i = 0; i < objAL.Count; i++)
                {
                    Product objProduct = objAL[i] as Product;
                    // objal.Sort();
                    objAL.Sort();
                    Console.WriteLine("Product Number :  " + objProduct.pnumber + "\nProduct Name :   " + objProduct.pname + "\nProduct Rating :  " + objProduct.prate + "\nProduct Stock :  " + objProduct.pstock);
                    Console.WriteLine("-----------------------------------------------------");
                }

                Console.ReadKey();
            }
        }
    }
    
}
