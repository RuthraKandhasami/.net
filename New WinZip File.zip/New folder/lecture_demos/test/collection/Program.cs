﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace collection
{
    class Program
    {
        static void Main(string[] args)
        {
            //non - genric collection
            DemoArraylist();
            DemoStack();
            DemoQueue();
            DemoHashtable();

            //Genric Collection
            Demolist();
            DemoGenricStack();
            DemoGenricQueue();
            DemoGenricDictionary();
            Console.ReadLine();
        }

        static void DemoArraylist() {
            Console.WriteLine("============================ ARRY LIST  =============================");
            ArrayList objal = new ArrayList();
            objal.Add(1);
            objal.Add("Australia");
            objal.Add("Russia");
            objal.Add("India");
            objal.Add("China");
            //
            Console.WriteLine("capacity:"+objal.Capacity);
            Console.WriteLine("COUNT:"+objal.Count);
            Console.WriteLine("======================= FOR LOOP ===========================");
            for (int i= 0;i< objal.Count;i++)
            {
                Console.WriteLine(objal[i]);
            }

            Console.WriteLine("======================= FOREACH LOOP ===========================");
            //
            foreach (var name in objal)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("======================= Object Array ===========================");
            Object[] objcountries = new object[objal.Count];
            objal.CopyTo(objcountries);
            foreach (var country in objcountries)
            {
                Console.WriteLine(country);
            }

            //
            Console.WriteLine("======================= checking Item  FOREACH LOOP ===========================");
            bool containItem = objal.Contains("India");
            Console.WriteLine("India is a part of collection="+containItem);

            //
            objal.Insert(2, "Africa");
            Console.Write("======================= after inserting FOREACH LOOP ===========================");
            
            foreach (var name in objal)
            {
                Console.WriteLine(name);
            }
            //
            objal.Remove("Africa");
            Console.WriteLine("======================= after removing FOREACH LOOP ===========================");
            
            foreach (var name in objal)
            {
                Console.WriteLine(name);
            }

            objal.Sort();
            Console.WriteLine("======================= after Sorting FOREACH LOOP ===========================");

            foreach (var name in objal)
            {
                Console.WriteLine(name);
            }
        }

        static void DemoStack() {
            Console.WriteLine("======================= STACK  ===========================");

            Stack objstack = new Stack();
            objstack.Push("Jan");
            objstack.Push("feb");
            objstack.Push("Mar");
            objstack.Push("Apl");
            objstack.Push("May");
            //
            Console.WriteLine("======================= FOREACH LOOP ===========================");
            foreach (var objmonth in objstack)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item poped : "+ objstack.Pop());
            foreach (var objmonth in objstack)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item peek : "+objstack.Peek());
            foreach (var objmonth in objstack)
            {
                Console.WriteLine(objmonth);
            }
        }

        static void DemoQueue() {
            Console.WriteLine("============================ QUEUE  =============================");
            Queue objQ = new Queue();
            objQ.Enqueue("Jan");
            objQ.Enqueue("Feb");
            objQ.Enqueue("Mar");
            objQ.Enqueue("Apl");
            objQ.Enqueue("May");
            //
            Console.WriteLine("======================= FOREACH LOOP ===========================");
            foreach (var objmonth in objQ)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item poped : " + objQ.Dequeue());
            foreach (var objmonth in objQ)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item peek : " + objQ.Peek());
            foreach (var objmonth in objQ)
            {
                Console.WriteLine(objmonth);
            }
        }

        static void DemoHashtable() {
            Console.WriteLine("============================ Hashtable  =============================");
            Hashtable objH = new Hashtable();
            objH.Add(101, "Anand0");
            objH.Add(102, "Anand1");
            objH.Add(103, "Anand2");
            objH.Add(104, "Anand3");
            objH.Add(105, "Anand4");
            //
            Console.WriteLine("======================= FOREACH LOOP ===========================");
            foreach (DictionaryEntry emp in objH)
            {
                Console.WriteLine("key: "+emp.Key + "\tValue:"+emp.Value);
            }
            //
            Console.WriteLine("======================= While LOOP ===========================");
            IDictionaryEnumerator emp1 = objH.GetEnumerator();
            while (emp1.MoveNext())
            {
                Console.WriteLine("key: " + emp1.Key + "\tValue:" + emp1.Value);
            }
        }

        static void Demolist()
        {
            Console.WriteLine("============================ DEMO GENRIC LIST  =============================");
            List<string> objL = new List<string>();
            objL.Add("America");
            objL.Add("Australia");
            objL.Add("Russia");
            objL.Add("India");
            objL.Add("China");
            //
            Console.WriteLine("capacity:" + objL.Capacity);
            Console.WriteLine("COUNT:" + objL.Count);
            Console.WriteLine("======================= FOR LOOP ===========================");
            for (int i = 0; i < objL.Count; i++)
            {
                Console.WriteLine(objL[i]);
            }

            Console.WriteLine("======================= FOREACH LOOP ===========================");
            //
            foreach (var name in objL)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("======================= Object Array ===========================");
            string[] objcountries = new string[objL.Count];
            objL.CopyTo(objcountries);
            foreach (var country in objcountries)
            {
                Console.WriteLine(country);
            }

            //
            Console.WriteLine("======================= checking Item  FOREACH LOOP ===========================");
            bool containItem = objL.Contains("India");
            Console.WriteLine("India is a part of collection=" + containItem);

            //
            objL.Insert(2, "Africa");
            Console.Write("======================= after inserting FOREACH LOOP ===========================");

            foreach (var name in objL)
            {
                Console.WriteLine(name);
            }
            //
            objL.Remove("Africa");
            Console.WriteLine("======================= after removing FOREACH LOOP ===========================");

            foreach (var name in objL)
            {
                Console.WriteLine(name);
            }

            objL.Sort();
            Console.WriteLine("======================= after Sorting FOREACH LOOP ===========================");

            foreach (var name in objL)
            {
                Console.WriteLine(name);
            }
        }

        static void DemoGenricStack()
        {
            Console.WriteLine("======================= GENRIC STACK  ===========================");

            Stack<string> objstack = new Stack<string>();
            objstack.Push("Jan");
            objstack.Push("feb");
            objstack.Push("Mar");
            objstack.Push("Apl");
            objstack.Push("May");
            //
            Console.WriteLine("======================= FOREACH LOOP ===========================");
            foreach (var objmonth in objstack)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item poped : " + objstack.Pop());
            foreach (var objmonth in objstack)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item peek : " + objstack.Peek());
            foreach (var objmonth in objstack)
            {
                Console.WriteLine(objmonth);
            }
        }

        static void DemoGenricQueue()
        {
            Console.WriteLine("============================ GENRIC QUEUE  =============================");
            Queue<string> objQ = new Queue<string>();
            objQ.Enqueue("Jan");
            objQ.Enqueue("Feb");
            objQ.Enqueue("Mar");
            objQ.Enqueue("Apl");
            objQ.Enqueue("May");
            //
            Console.WriteLine("======================= FOREACH LOOP ===========================");
            foreach (var objmonth in objQ)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item poped : " + objQ.Dequeue());
            foreach (var objmonth in objQ)
            {
                Console.WriteLine(objmonth);
            }
            //
            Console.WriteLine("Item peek : " + objQ.Peek());
            foreach (var objmonth in objQ)
            {
                Console.WriteLine(objmonth);
            }
        }

        static void DemoGenricDictionary()
        {
            Console.WriteLine("============================ GENRIC Hashtable  =============================");
            Dictionary<int,string> objH = new Dictionary<int, string>();
            objH.Add(101, "Anand0");
            objH.Add(102, "Anand1");
            objH.Add(103, "Anand2");
            objH.Add(104, "Anand3");
            objH.Add(105, "Anand4");
            //
            Console.WriteLine("======================= FOREACH LOOP ===========================");
            foreach (KeyValuePair<int,string> emp in objH)
            {
                Console.WriteLine("key: " + emp.Key + "\tValue:" + emp.Value);
            }
            //
            Console.WriteLine("======================= While LOOP ===========================");
            IDictionaryEnumerator emp1 = objH.GetEnumerator();
            while (emp1.MoveNext())
            {
                Console.WriteLine("key: " + emp1.Key + "\tValue:" + emp1.Value);
            }
        }
    }
}
