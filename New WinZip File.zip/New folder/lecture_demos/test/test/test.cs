﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using calculatorlib;

namespace test
{
    class test
    {
        

        static void Main(string[] args)
        {
            char x;
            int n1, n2;
            char choice;

            do
            {
                Console.Write("Enter 1st number = ");
                n1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter 2st number = ");
                n2 = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter operater = ");
                x = Convert.ToChar(Console.ReadLine());

               
                calculatorlib.calculator obj = new calculatorlib.calculator();

                switch (x)
                {
                    case '+':
                        Console.WriteLine("Answer = " + obj.Addition(n1, n2));
                        
                        break;
                    case '-':
                        Console.WriteLine("Answer = " + obj.Sub(n1, n2));
                        
                        break;
                    case '*':
                        Console.WriteLine("Answer = " + obj.Multi(n1, n2));
                     
                        break;
                    case '/':
                        Console.WriteLine("Answer = " + obj.div(n1, n2));
                        
                        break;
                    case '1':
                        Environment.Exit(0);
                        break;

                }
                Console.WriteLine("do you want to continue? Press 'y' or 'n' =");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y');
           
        }
        }
    }