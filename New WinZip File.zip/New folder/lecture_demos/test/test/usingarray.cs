﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class usingarray
    {
        public static void Main(String[] args)
        {
            ONEDARR();
            TOWDARR();
            Console.ReadKey();
        }
        static void ONEDARR()
        {
            string[] strcities = new string[5];
            strcities[0]= "Delhi";
            strcities[1]= "mumbai";
            strcities[2]= "kolkata";
            strcities[3]= "chennai";
            strcities[4] = "uk";

            Console.WriteLine("-----------------------list of cities using for loop------------------");
            for (int i = 0; i < strcities.Length-1; i++)
            {
                Console.WriteLine(strcities[i]);
            }
            Console.WriteLine("-----------------------list of cities using foreach loop------------------");
            foreach (string str in strcities)
            {
                Console.WriteLine(str);
            }
        }
        static void TOWDARR()
        {
            int[,] num = new int[2,2];
            num[0,0] = 101;
            num[0,1] = 102;
            num[1,0] = 201;
            num[1,1] = 202;
            Console.WriteLine("---------------------Tow D Array----------------------");
            for (int i = 0; i < num.GetLength(0); i++)
            {
                for(int j = 0; j < num.GetLength(1); j++)
                {
                    Console.Write(num[i, j]+"\t");
                }
                Console.WriteLine();
            }
            
        }
    }
}
