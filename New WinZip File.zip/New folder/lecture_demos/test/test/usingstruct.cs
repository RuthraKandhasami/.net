﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    internal struct usingstruct
    {
        internal int rollno;
        internal string name, grade;

        public usingstruct(int rollno,string name , string grade )
        {
            this.rollno = rollno;
            this.name = name;
            this.grade = grade;
        }
    }
}
