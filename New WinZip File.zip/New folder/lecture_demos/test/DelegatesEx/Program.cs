﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEx
{
    class Program
    {
        //ctrating instance og delegate
        calculator cal = new calculator();
        delegate int Arithimeticoperation(int a, int b);
        static void Main(string[] args)
        {
            calculator cal = new calculator();
            int result;

            //demo unicast delegate 1
            Arithimeticoperation obj = new Arithimeticoperation(cal.Add);
            result = obj.Invoke(12, 24);
            Console.WriteLine("Addtion using unicast Delegates = " + result);


            //demo unicast delegate 2
            Arithimeticoperation obj1 = new Arithimeticoperation(cal.sub);
            obj.Invoke(12, 24);
            Console.WriteLine("Addtion using unicast Delegates = " + result);

            //demo multicast delegate
            Arithimeticoperation objm;
            objm = obj;
            result = objm.Invoke(24, 4);
            Console.WriteLine("Addtion using multicast Delegates = " + result);
            objm += obj1;
            ///objm(14, 42);
            result = objm.Invoke(24, 4);
            Console.WriteLine("Addtion using multicast Delegates = " + result);

            // demo of delegate invocatiojn List
            Delegate[] objdelegate = objm.GetInvocationList();
            foreach (Delegate objdele in objdelegate)
            {
                Arithimeticoperation objGIL = objdele as Arithimeticoperation;
                Console.WriteLine("Output from individual delegate = " + objGIL.Invoke(12, 6));

            }


            ////Demo Asynchronus delegate
            Arithimeticoperation objAsync = new Arithimeticoperation(cal.Add);
            IAsyncResult asyncResult = objAsync.BeginInvoke(21, 22, null, null);

            int resultsub = cal.sub(12, 5);
            int resultadd = objAsync.EndInvoke(asyncResult);

            // Anonymus Delegates
            Arithimeticoperation objAOHnon = delegate (int num1, int num2)
            {
                int resu;
                resu = num1 + num2;
                return resu;
            };
            int resultAnon = objAOHnon.Invoke(100,20);
            Console.WriteLine("Addition of 2 numbers using Anonymus Delegates:"+resultAnon);

            //}

            Console.ReadKey();

        }
    }
}
