﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEx
{
    class calculator
    {
        internal int Add(int a,int b)
        {
            int r;
            r = a + b;
            //for (int i = 0; i < 50; i++)
            //{
            //    Console.WriteLine("Value of addition = " + i);
            //}
            return r;
        }

        internal int sub(int a, int b)
        {
            int r;
            r = a - b;
            //for (int i = 0; i < 50; i++)
            //{
            //    Console.WriteLine("Value of Subraction = " + i);
            //}
            return r;
        }

        internal int multi(int a, int b)
        {
            int r;
            r = a * b;
            return r;
        }

        internal int div(int a, int b)
        {
            int r;
            r = a / b;
            return r;
        }
    }
}
