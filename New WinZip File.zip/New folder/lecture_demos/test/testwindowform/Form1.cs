﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using calculatorlib;

namespace testwindowform
{
    public partial class Form1 : Form
    {
        calculatorlib.calculator obj;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             obj = new calculatorlib.calculator();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b,result;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            result = obj.Addition(a, b);
            textBox3.Text = Convert.ToString(result);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a, b, result;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            result = obj.Sub(a, b);
            textBox3.Text = Convert.ToString(result);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a, b, result;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            result = obj.Multi(a, b);
            textBox3.Text = Convert.ToString(result);
        }

        private void l_Click(object sender, EventArgs e)
        {
            int a, b, result;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            result = obj.div(a, b);
            textBox3.Text = Convert.ToString(result);
        }
    }
}
