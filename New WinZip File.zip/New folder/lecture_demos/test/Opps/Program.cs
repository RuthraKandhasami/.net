﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opps
{
    class Program
    {
        static void Main(string[] args)
        {
            int l, b,s;
            int choice;
            char c;
            do
            {
                Console.WriteLine("Select '1' for rectangle and select '2' for Square");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter length of reactangle=");
                        l = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter breadth of reactangle=");
                        b = Convert.ToInt32(Console.ReadLine());
                        rectangle obj1 = new rectangle(l, b);
                        obj1.calculateArea();
                        Console.WriteLine("Area of Rectangle = " + obj1.Area);
                        obj1.calculatePeri();
                        Console.WriteLine("Perimeter of Rectangle = " + obj1.Peri);
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.Write("Enter side of Square=");
                        s = Convert.ToInt32(Console.ReadLine());
                        square obj2 = new square(s);
                        obj2.calculateArea();
                        Console.WriteLine("Area of Square = " + obj2.Area);
                        obj2.calculatePeri();
                        Console.WriteLine("Perimeter of Square = " + obj2.Peri);
                        Console.ReadKey();
                        break;
                    default:
                        Console.Write("Error!!!");
                        break;
                }
                Console.WriteLine("do you want to continue? Press 'y' or 'n' =");
                c = Convert.ToChar(Console.ReadLine());
            } while (c == 'y');
        }
    }
}
