﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opps
{
    class shape
    {
         int area;
         int peri;

        public int Area
        {
            get {
                return area;
            }
            set {
                area = value;
            }
        }

        public int Peri
        {
            get
            {
                return peri;
            }
            set
            {
                peri = value;
            }
        }
        public shape() { }
        internal virtual void calculateArea()
        {
           
        }
        internal virtual void calculatePeri()

        {

        }
    }
}
