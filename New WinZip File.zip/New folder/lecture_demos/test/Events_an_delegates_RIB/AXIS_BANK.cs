﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events_an_delegates_RIB
{
    class AXIS_BANK
    {
        static void Main(string[] args)
        {
            RBI objRbi = new RBI(500000);
            objRbi.underBalance += new AccountHandeler(AxisPolicies.Penalty);
            objRbi.overBalance += new AccountHandeler(AxisPolicies.PayTax);
            //
            //objRbi.Withdraw(499600);
            objRbi.Deposit(5100000);

            Console.ReadKey();
        }
    }
    internal class AxisPolicies
    {
        internal static void Penalty()
        {
            Console.WriteLine("Axisbank Penalty:");
        }
        internal static void PayTax()
        {
            Console.WriteLine("AxisBank Pay Tax:");
        }
    }
}
