﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Serialization_demo
{
    [Serializable]
    public class Employee
    {
        public int EmpID
        {
            get;
            set;
        }
        public String EmpName
        {
            get;
            set;
        }
        public int DesignationID
        {
            get;
            set;
        }
        public int DepartmentID
        {
            get;
            set;
        }
        public int DOB
        {
            get;
            set;
        }

        [NonSerialized]
        public int age;
        public int Age
        {
            get { return age; }
            set {value = age; }
        }
        public void onDeserial( )
        {
            age = DateTime.Now.Year - DOB;
        }

        
    }
}
