﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LAB12_Q2
{
    class Program
    {
        static string sourceFilePath, destinationFilePath;
        static void Main(string[] args)
        {
                Console.WriteLine("Enter Source File Name that you Want to copy :");
                sourceFilePath = Console.ReadLine();
                Console.WriteLine("Enter Destination File Name where you want to copy :");
                destinationFilePath = Console.ReadLine();
                CopyFile_UsingFileClass();
        }
        static void CopyFile_UsingFileClass()
        {
            string strFilePath = @"C:\ForFileIO\"+sourceFilePath;
            string strFileDestinationPath = @"C:\ForFileIO\"+destinationFilePath;
            if (File.Exists(strFileDestinationPath))
            {
                Console.WriteLine("The Destination File Name is Already Exists.");
            }
            else if (!File.Exists(strFilePath))
            {
                Console.WriteLine("The Source File not Exists.");
            }else if(File.Exists(strFilePath))
            {
                File.Copy(strFilePath, strFileDestinationPath);
                if (File.Exists(strFileDestinationPath))
                {
                    Console.WriteLine("File Copied Successfully.");
                }
                else
                {
                    Console.WriteLine("File could not be Copied.");
                }
            }
        }
    }
}
