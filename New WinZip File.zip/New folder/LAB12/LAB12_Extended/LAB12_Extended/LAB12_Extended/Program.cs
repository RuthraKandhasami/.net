﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LAB12_Extended
{
    class Program
    {
        static string c;
        static void Main(string[] args)
        {


            int choice;
            char ch;
            

            do
            {
                Console.WriteLine("================================== Menu =================================" +
                    "\n 1 to Create Directory" +
                    "\n 2 to Create File" +
                    "\n 3 to Store Batch Details" +
                    "\n 4 to Get Backup" +
                    "\n 5 to View Details" +
                    "\n =================================================================== ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:

                        string c=Choice();
                        createDirectory(c);
                        break;
                    case 2:
                         c = Choice();
                        CreateFile(c);
                        break;
                    case 3:
                        c = Choice();
                        GetBatchDetails(c);
                        break;
                    case 4:
                        c = Choice();
                        GetBackUpCopy(c);
                        break;
                    case 5:
                        c = Choice();
                        ViewDetails(c);
                        break;
                    default:
                        break;
                }
                Console.WriteLine("------------------------------------------------------------");
                Console.WriteLine("Do u want to Continue? press 'y' to Continue and 'n' to Exit. ");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch =='y');
        }
        static void createDirectory(string path)
        {

            string strDirectoryPath = @"C:\Academy\"+path;
            if (!Directory.Exists(strDirectoryPath))
            {
                Directory.CreateDirectory(strDirectoryPath);
                if (Directory.Exists(strDirectoryPath))
                {
                    Console.WriteLine("Directory Created Successfully.");
                }
                else
                {
                    Console.WriteLine("Directory could not beCreated ");
                }
            }
            else
            {
                Console.WriteLine("Directory Already exists...");
            }
        }
        static void CreateFile(string path)
        {
            string file = path.ToLower() + ".txt";
            string finalPath = @"C:\Academy\" + path + "\\" + file;

            if (File.Exists(finalPath))
            {
                Console.WriteLine("The {0} File is Already Exists.",path);
            }
            else 
            {
                FileStream objFS = new FileStream(finalPath, FileMode.Create, FileAccess.Write, FileShare.Read);
                objFS.Close();
                Console.WriteLine("File Created Successfully in {0} Folder ", path);
            }
        }
        static void GetBatchDetails(string path)
        {
            string file = path.ToLower() + ".txt";
            string finalPath = @"C:\Academy\" + path + "\\" + file;
            Console.WriteLine("Enter the Batch Domain :");
            string domain = Console.ReadLine();
            Console.WriteLine("Enter the Date of Joing in (mm/dd/yy) :");
            DateTime doj = Convert.ToDateTime(Console.ReadLine());
           
         
                FileStream objFS = new FileStream(finalPath, FileMode.Append, FileAccess.Write, FileShare.Read);
                StreamWriter objSW = new StreamWriter(objFS);
                objSW.WriteLine("Batch Domain : "+ domain + ", Date of Joining :" + doj);
                if (objFS != null)
                {
                    Console.WriteLine("File {0} Updated Successfully.",path);
                }
            objSW.Flush();
            objFS.Flush();
            objFS.Close();
        } 
        static void GetBackUpCopy(string path)
        {
            string file = path.ToLower() + ".txt";
            string finalPath = @"C:\Academy\" + path + "\\" + file;
            Console.WriteLine("Enter Destination File Name :");
            string destinationFilePath = Console.ReadLine();
            string strFileDestinationPath = @"D:\" + destinationFilePath;
            if (File.Exists(strFileDestinationPath))
            {
                Console.WriteLine("The {0} File Name is Already Exists.",destinationFilePath);
            }
            else if (!File.Exists(finalPath))
            {
                Console.WriteLine("The {0} File not Exists.",path);
            }
            else if (File.Exists(finalPath))
            {
                File.Copy(finalPath, strFileDestinationPath);
                if (File.Exists(strFileDestinationPath))
                {
                    Console.WriteLine("File {0} Backup Successfully.",path);
                }
                else
                {
                    Console.WriteLine("Backup Failed.");
                }
            }
        }
        static void ViewDetails(string path)
        {
            string file = path.ToLower() + ".txt";
            string finalPath = @"C:\Academy\" + path + "\\" + file;
            FileStream objFS = new FileStream(finalPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader objSR = new StreamReader(objFS);
            string strDataFromFile = objSR.ReadToEnd();
            objSR.Close();
            objFS.Close();
            Console.WriteLine("============= {0} ===============\n {1}" ,path, strDataFromFile);
        }
        static string Choice()
        {
            Console.WriteLine("========================= Choose From Following ===================================" +
                   "\n 1 to Mumbai" +
                   "\n 2 to Pune" +
                   "\n 3 to Banglore" +
                   "\n 4 to Chennai" +
                   "\n ============================================================================== ");
            int choice = Convert.ToInt32(Console.ReadLine());
            string[] dir = new string[] { "Mumbai", "Pune" , "Banglore" , "Chennai" };
            string path = dir[choice - 1];
            return path;
        }
       
    }
}
