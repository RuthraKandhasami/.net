﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandlingEntities
{
    public class Guest
    {
        private int guestID;
        private string guestName;
        private string guestContactNumber;
        

        public int GuestID
        {
            get { return guestID; }
            set { guestID = value; }
        }
        

        public string GuestName
        {
            get { return guestName; }
            set { guestName = value; }
        }
        

        public string GuestContactNumber
        {
            get { return guestContactNumber; }
            set { guestContactNumber = value; }
        }

        public Guest()
        {
            guestID = 0;
            guestName = string.Empty;
            guestContactNumber = string.Empty;
        }
    }
}
