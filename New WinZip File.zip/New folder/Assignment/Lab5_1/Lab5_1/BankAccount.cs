﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_1
{
    public abstract class BankAccount
    {
        public decimal Deposit { get; protected set; }

        protected decimal Withdraw { get; set; }

        protected decimal Transfer { get; set; }
        protected double balance { get; set; }

        protected BankAccount()
        {
         Deposit = deposit;
        Withdraw =  Withdraw;
        Transfer = transfer;
        }
    }
}
    public enum BankAccountTypeEnum
    {
        Current = 1,
        Saving = 2
    }

public interface IBankAccount
{
    double GetBalance();
    void Deposit(double amount);
    bool Withdraw(double amount);
    bool Transfer(IBankAccount toAccount, double amount);
    BankAccountTypeEnum AccountType { get; set; }
}
        public decimal CalculateInterest()
        {
            return (this.AccountBalance * this.InteresetRate) / 100;
        }

        // This method adds a Reporting functionality 
        public virtual void GenerateAccountReport()
        {
            Console.WriteLine("Account Owner:{0}, Account Number:{1}, AccountBalance:{2}",
                this.AccountOwnerName, this.AccountNumber, this.AccountBalance);

            Console.WriteLine("Interest Amount:{0}", CalculateInterest());
            Console.WriteLine("{0}", this.TransactionSummary);
        }
    }
