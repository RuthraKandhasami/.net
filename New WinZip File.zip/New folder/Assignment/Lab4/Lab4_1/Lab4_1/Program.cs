﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    class Program
    {
        static void Main(string[] args)
        {
        }

        int empid;
        string empname;
        string address;
        string city;
        string dept;
        int salary;
        public int EmployeeId
        {
            get
            {
                return empid;

            }
            set
            {
                empid = value;
            }
        }
        public string EmployeeName
        {
            get
            {
                return empname;
            }
            set
            {
                empname = value;

            }
        }
        public string Address
        {
            get

            {
                return address;
            }
            set
            {
                address = value;
            }
        }
        public string City
        {
            get

            {
                return city;
            }
            set
            {
                city = value;
            }
        }
        public string Department
        {
            get

            {
                return dept;
            }
            set
            {
                dept = value;
            }
        }
        public int Salary
        {
            get

            {
                return salary;
            }
            set
            {
                salary = value;
            }
        }

    }




}
