﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_2
{
  
        public class Triangle : Shape
        {
            public void WhoamI()
            {
                Console.WriteLine("I m Triangle");
            }
        }
    
}
