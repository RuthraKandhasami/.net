﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int customerId;
            string customername;
            String address;
            String city;
            int phone;
            int creditlimit;
            Console.WriteLine("customerid");
            customerId = Convert.ToInt32(Console.ReadLine());
        }
    }
}
