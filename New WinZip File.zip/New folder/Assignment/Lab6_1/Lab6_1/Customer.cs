﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_1
{
    class Customer
    {
        int customerId;
        string customername;
        String address;
        String city;
        int phone;
        int creditlimit;

        public int CustomerId
        {
            get
            {
                return customerId;


            }
            set
            {
                customerId = value;


            }
        }
        public string CustomerName
        {
            get
            {
                return customername;


            }
            set
            {
                customername = value;


            }
        }
        public string Address
        {
            get
            {
                return address;


            }
            set
            {
                address = value;


            }
        }
        public string City
        {
            get
            {
                return city;


            }
            set
            {
                city = value;


            }
        }
        public int Phone
        {
            get
            {
                return phone;


            }
            set
            {
                phone = value;


            }
        }
        public int Creditlimit
        {
            get
            {
                return creditlimit;


            }
            set
            {
                creditlimit = value;


            }
        }

        public Customer(int customerId, string customername, String address, String city, int phone, int creditlimit)
        {
            CustomerId = customerId;
            CustomerName = customername;
            Address = address;
            City = city;
            Phone = phone;
            Creditlimit = creditlimit;
        }



        public class CreditLimitException : Exception
        {
            public CreditLimitException(string message) : base(message)
            {
            }
            public class CreditLimit
            {
                int Creditlimit = 50000;
                public void showCredit()
                {
                    if (Creditlimit > 50000)
                    {
                        throw (new CreditLimitException("Invalid entry"));

                    }
                    else
                    {
                        Console.WriteLine("creditlimit:{50000}", Creditlimit);

                    }
                }
            }
        }
    }
}


