﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l10q2
{
    public delegate int ArithmeticOperationHandler(int num1, int num2);
    internal class ArithmeticOperations
    {
        static void Main(string[] args)
        {

            //anonymous delegate
            
            ArithmeticOperations obj = new ArithmeticOperations();
            ArithmeticOperationHandler objAOHadd = delegate (int num1, int num2)
            {
                int res;
                res = num1 + num2;
                return res;
            };
            int resultAddition = PerformArithmeticOperation(10, 20, objAOHadd);
            Console.WriteLine("Addition is: " + resultAddition);
            
            ArithmeticOperationHandler objAOHsub = delegate (int num1, int num2)
            {
                int res;
                res = num1 - num2;
                
                return res;
            };
            int resultSubtraction = PerformArithmeticOperation(20, 10, objAOHsub);
            Console.WriteLine("Addition is: " + resultSubtraction);

            ArithmeticOperationHandler objAOHmul = delegate (int num1, int num2)
            {
                int res;
                res = num1 * num2;
                return res;
            };
            int resultMultiplication = PerformArithmeticOperation(20, 10, objAOHmul);
            Console.WriteLine("Addition is: " + resultMultiplication);

            ArithmeticOperationHandler objAOHdiv = delegate (int num1, int num2)
            {
                int res;
                res = num1 * num2;
                return res;
            };
            int resultDivision = PerformArithmeticOperation(20, 10, objAOHmul);
            Console.WriteLine("Addition is: " + resultDivision);

            ArithmeticOperationHandler objAOHmax = delegate (int num1, int num2)
            {
                int res = Math.Max(num1, num2);
                return res;
            };
            int resultmax = PerformArithmeticOperation(20, 10, objAOHmax);
            Console.WriteLine("Addition is: " + resultmax);
            
            Console.ReadKey();

        }
        internal static int PerformArithmeticOperation(int num1, int num2, ArithmeticOperationHandler objAOH)
        {
            int result = objAOH(num1, num2);
            return result;
        }
    }
}
