﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string key, value;
            char select;
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("1", "Ruthra");
            names.Add("2", "Aishu");
            names.Add("3", "Pragathi");
            names.Add("4", "Humera");
            do
            {
                Console.WriteLine(" Select your choice : \n 1: Add \n 2: Update \n 3: Remove \n 4: Display");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        try
                        {
                            Console.WriteLine("Enter key : ");
                            key = Console.ReadLine();
                            Console.WriteLine("Enter value : ");
                            value = Console.ReadLine();
                            foreach (KeyValuePair<string, string> check in names)
                            {
                                if (check.Key == key)
                                {
                                    throw new KeyAlreadyExists("Key entered already exists in Directory");
                                }
                            }
                            names.Add(key, value);
                            Console.WriteLine("---------------------------------------------------------------");
                            Console.WriteLine("-------->>>KeyValue pair successfully added<<<---------");

                        }
                        catch (KeyAlreadyExists j)
                        {
                            Console.WriteLine(j);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter index to Update : ");
                        int index = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter value to update : ");
                        string objVal = Console.ReadLine();
                        string objKey = names.ElementAt(index).Key;
                        names.Remove(objKey);
                        names.Add(objKey, objVal);
                        string b = names.ElementAt(index).Value;
                        Console.WriteLine("---------------------------------------------------------------");
                        Console.WriteLine("---------->>>KeyValue pair successfully Updated<<<---------");
                        Console.WriteLine("---------------------------------------------------------------");
                        Console.WriteLine(" Key = " + objKey + " Value = " + b);

                        break;
                    case 3:
                        Console.WriteLine("Enter key to remove : ");
                        string nkey = Console.ReadLine();
                        names.Remove(nkey);
                        Console.WriteLine("---------------------------------------------------------------");
                        Console.WriteLine("---------->>>KeyValue pair successfully Removed<<<---------");

                        break;
                    case 4:
                        Console.WriteLine("-------List of cities in Dictionary-------");
                        Console.WriteLine(" ");
                        foreach (KeyValuePair<string, string> obj in names)
                        {
                            Console.WriteLine(" key : " + obj.Key + " " + "   Value : " + obj.Value + "\n");
                        }
                        break;
                    default:

                        Console.WriteLine("----->>You selected wrong number<<------");
                        break;
                }
                Console.WriteLine("-------------------------------------------------------");
                Console.WriteLine("for continue press 'y' else press 'n' ");
                select = Convert.ToChar(Console.ReadLine());
                if (select != 'y' || select != 'n')
                {
                    Console.WriteLine("------------------OKAY!!!--------------------");
                }
                else Environment.Exit(0);
            } while (select == 'y');

        }
    }
    
}
