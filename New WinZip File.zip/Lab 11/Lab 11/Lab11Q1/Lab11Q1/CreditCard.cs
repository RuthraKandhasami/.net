﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11_1
{
    delegate void CreditHandler();
    class CreditCard
    {
        internal event CreditHandler makePayment;
        int creditCardNo; 
        static int creditLimit=100000;
        int balanceAmount=creditLimit;
        string cardHolderName;
        public CreditCard(int ccno, string chname)
        {


















































































































            this.creditCardNo = ccno;
            this.cardHolderName = chname;  
        }
        public int getbalance()
        {
            return balanceAmount;
        }
        public int Getcreditlimit()
        {
            return creditLimit;
        }
        public void MakePayment(int paymentAmount)
        {
            if (creditCardNo == 105042124 && cardHolderName == "ruthra" && paymentAmount <= balanceAmount)
            {
                balanceAmount = balanceAmount - paymentAmount;
                makePayment();
                Console.WriteLine("Updated Balance Is : " + balanceAmount);
                Console.ReadLine();
            }
            else
                Console.WriteLine("Transaction Failed");
                Console.ReadLine();
        }
    }
}
