﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L_4Q_2
{
    class Program
        {
             static void Main(string[] args)
                 {
                         Shape s;
                         s = new Triangle();
                         s.WhoamI();
                         s = new Circle();
                         s.WhoamI();
                         Console.ReadKey();
                 }
        }
}
