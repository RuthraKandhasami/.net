﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab4_1;

namespace Lab4_1
{
    public class ContractEmployee : Employee
    {
        public static double perks;
        public static Employee emp1 = new Employee();


        public double Perks
        {
            get {return perks; } set { perks = value; }

        }

        public ContractEmployee(int EId,string EName,string Address,string City,string Dept,int Salary)
        {
            emp1 = new Employee();
            
        }
        public double getSalary()
        {
             
            double Sal = emp1.Salary + perks;
            return Sal;
        }

        
    }
}
