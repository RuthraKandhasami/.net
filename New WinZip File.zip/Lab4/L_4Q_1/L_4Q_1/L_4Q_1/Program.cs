﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using L_1Q_1;

namespace Lab4_1
{
    class Program 
    {
       internal static int EmpId;
       internal static string EmployeeName;
       internal static string Address;
       internal static string City;
       internal static string Dept;
        internal static int Sal;
        static void Main(string[] args)
        {

            Console.WriteLine("Employee type as contract or permanent.");
            Console.WriteLine("Press 1 for contract employee and 2 for permanent employee");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                case 1: Console.WriteLine("Enter contract Employee Details");
                    setContractEmployeeDetails();
                    break;

                case 2: Console.WriteLine("Enter Permanent employee details:-");
                    setPermenantEmployeeDetails();
                    break;

                default:  Console.WriteLine("Inavlid Input");
                    break;
            }
            Console.ReadLine();

        }

        internal static void setContractEmployeeDetails()
        {
            Console.WriteLine("Enter id:");
            EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name:");
            EmployeeName = Console.ReadLine();
            Console.WriteLine("Enter address:");
            Address = Console.ReadLine();
            Console.WriteLine("Enter City:");
            City = Console.ReadLine();
            Console.WriteLine("Enter Dept:");
            Dept = Console.ReadLine();
            Console.WriteLine("Enter base Salary:");
            Sal = Convert.ToInt32(Console.ReadLine());

            ContractEmployee ContEmp = new ContractEmployee(EmpId, EmployeeName, Address, City, Dept, Sal);
            Console.WriteLine("Enter Perks amount:");
            ContEmp.Perks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Contract employees gross salary =" + ContEmp.getSalary());
          


        }
        internal static void setPermenantEmployeeDetails()
        {
            Console.WriteLine("Enter id:");
            EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name:");
            EmployeeName = Console.ReadLine();
            Console.WriteLine("Enter address:");
            Address = Console.ReadLine();
            Console.WriteLine("Enter City:");
            City = Console.ReadLine();
            Console.WriteLine("Enter Dept:");
            Dept = Console.ReadLine();
            Console.WriteLine("Enter base Salary:");
            Sal = Convert.ToInt32(Console.ReadLine());

            PermanentEmployee PerEmp= new PermanentEmployee(EmpId, EmployeeName, Address, City, Dept, Sal);

            Console.WriteLine("Enter PF amount:");
            PerEmp.PF = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Contract employees gross salary =" + PerEmp.getSalary());
        }
    }
}
