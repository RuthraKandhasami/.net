﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L_1Q_1
{
    class Employee
    {
        int EId;
        string EName;
        string Address;
        string City;
        string Department;
        int Salary;

        public int EID
        {
            get
            {
                return EId;
            }
            set
            {
                EId = value;
            }
           
        }

        public string ENAME
        {
            set
            {
                EName = value;
            }
            get
            {
                return EName;
            }
        }

        public string ADDRESS
        {
            set
            {
                Address = value;
            }
            get
            {
                return Address;
            }
        }

        public string CITY
        {
            set
            {
               City = value;
            }
            get
            {
                return City;
            }
        }

        public string DEPARTMENT
        {
            set
            {
                Department = value;
            }
            get
            {
                return Department;
            }
        }
        public int SALARY
        {
            set
            {
                Salary = value;
            }
            get
            {
                return Salary;
            }
        }

        public Employee()
        {

        }
        public Employee(int EId, string EName, string Address ,string Department, string City, int Salary)
        {
            this.EId = EId;
            this.EName = EName;
            this.Address = Address;
            this.Department = Department;
            this.City = City;
            this.Salary = Salary;
        }

    }
}
