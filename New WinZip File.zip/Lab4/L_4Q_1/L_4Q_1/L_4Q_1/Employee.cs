﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    public class Employee
    {
        int EmpId;
        string EName;
        string Address;
        string City;
        string Dept;
        double Sal;
        
        public int EmployeeId
        {
            get
            {
                return EmpId;

            }
            set
            {
                EmpId = value;
            }
        }
        public string EmployeeName
        {
            get
            {
                return EName;
            }
            set
            {
                EName = value;

            }
        }
        public string ADdress
        {
            get

            {
                return Address;
            }
            set
            {
                Address = value;
            }
        }
        public string CIty
        {
            get

            {
                return City;
            }
            set
            {
                City = value;
            }
        }
        public string Department
        {
            get

            {
                return Dept;
            }
            set
            {
                Dept = value;
            }
        }
        public double Salary
        {
            get

            {
                return Sal;
            }
            set
            {
                Sal = value;
            }
        }
    }
}
