﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab4_1;

namespace Lab4_1

{
    class PermanentEmployee : Employee
    {
        private static int NoOfLeaves;
        private static int Pf;
        public static Employee emp1 = new Employee();
        public int NumberOfLeaves
        {
            get { return NoOfLeaves; }
            set { NoOfLeaves = value; }
        }
        public int PF
        {
            get { return Pf; }
            set { Pf = value; }
        }
        public PermanentEmployee(int EmpId, string EmployeeName, string Address, string City, string Dept, int Sal)
        {
            emp1 = new Employee();

        }

        public double getSalary()
        {

            double Sal = emp1.Salary - Pf;
            return Sal;
        }
    }
}
