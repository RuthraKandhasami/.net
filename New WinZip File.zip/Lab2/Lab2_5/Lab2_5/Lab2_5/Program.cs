﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_5
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] columnName = new string[4] { "Book_Title", "Author", "Publisher", "Price" };
            string[,] BooksDetails = new string[2, 4];
            for (int i = 0; i < BooksDetails.GetLength(0); i++)
            {
                Console.WriteLine("\nEnter the book's details :" + (i + 1));
                for (int j = 0; j < BooksDetails.GetLength(1); j++)
                {
                    Console.Write("\nEnter the {0} : ", columnName[j]);
                    BooksDetails[i, j] = Console.ReadLine();
                }
            }
            //
            Console.WriteLine("\n<<-------->> Details of Books <<-------->>");

            foreach (string Str in columnName)
            {
                Console.Write(Str + " ");
            }
            for (int i = 0; i < BooksDetails.GetLength(0); i++)
            {
                Console.WriteLine("");
                //Console.WriteLine("\nDetails of Book :" + (i + 1));
                for (int j = 0; j < BooksDetails.GetLength(1); j++)
                {
                    //Console.WriteLine(colName[j]+":  "+BookDetails[i, j]);
                    Console.Write(BooksDetails[i, j]);
                    Console.Write("\t   ");
                  //{
                      //  int AmountPayable;

                       // AmountPayable = (i + 1)+ (j + 1);
                    //Console.WriteLine("AmountPayable:" + AmountPayable);
                    //}
                }

            }

            Console.ReadLine();
        }
    }
    
}
