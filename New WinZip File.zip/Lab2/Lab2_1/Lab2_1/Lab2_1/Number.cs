﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_1
{
    struct Number
    {
        public int num;

        public Number(int number)
        {
            num = number;
        }

        public int Square()
        {
            int result;
            result = num * num;
            return result;
        }

        public int Cube()
        {
            int result;
            result = num * num * num;
            return result;
        }
    }
}
