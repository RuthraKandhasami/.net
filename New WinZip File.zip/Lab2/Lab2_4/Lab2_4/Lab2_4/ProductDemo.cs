﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_4
{
    class ProductDemo
    {
        static void Main(string[] args)
        {
            object objProductId, objProName, objProPrice, objProQuantity;
            double AmounPayable;

            Console.Write("Enter the id of product : ");
            objProductId = Console.ReadLine();
            Console.Write("\nEnter the name of product : ");
            objProName = Console.ReadLine();
            Console.Write("\nEnter price : ");
            objProPrice = Console.ReadLine();
            Console.Write("\nEnter quantity : ");
            objProQuantity = Console.ReadLine();
            //unboxing
            int ProID = Convert.ToInt32(objProductId);
            int ProQuantity = Convert.ToInt32(objProQuantity);
            int ProPrice = Convert.ToInt32(objProPrice);
            //
            AmounPayable = ProQuantity * ProPrice;
            //
            Console.WriteLine("\n\n---------- Product Details ------- ");
            Console.WriteLine("Product ID : " + ProID);
            Console.WriteLine("Product Name : " + objProName.ToString());
            Console.WriteLine("Price : " + ProPrice);
            Console.WriteLine("Quantity : " + ProQuantity);
            Console.WriteLine("Amt Payable : " + AmounPayable);
            Console.ReadLine();
        }
    }
}
