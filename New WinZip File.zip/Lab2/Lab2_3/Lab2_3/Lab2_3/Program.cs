﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_3
{
    class Program
    {
        static string[] Citynames = new string[4];
        static void Main(string[] args)
        {
        GetCityNames();
        DisplayNames();
        Console.ReadKey();

        }

    static void GetCityNames()
    {
        Console.WriteLine("-----Getting the names of the cities---");
        Console.WriteLine("Enter the city names ");
        for (int i = 0; i < Citynames.Length; i++)
            Citynames[i] = Convert.ToString(Console.ReadLine());


    }

    static void DisplayNames()
    {
        Console.WriteLine("---display city names---");
        foreach (string city in Citynames)
        {
            Console.WriteLine(city);
        }
    }

    
}
