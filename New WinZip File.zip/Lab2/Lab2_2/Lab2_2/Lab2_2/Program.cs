﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_2
{
    class Program
    {

        static int[,] TwoDArray = new int[5, 6];
        static void Main(string[] args)
        {
            AccData();

            DisplayDetails();

            Console.ReadLine();
        }

        static void AccData()
        {
            Console.WriteLine("----getting values from user----");
            for (int i = 0; i < TwoDArray.GetLength(0); i++)
            {
                Console.WriteLine("values for Row :" + i);
                for (int j = 0; j < TwoDArray.GetLength(1); j++)
                {
                    Console.WriteLine("values for column :" + j);
                    TwoDArray[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
        }
        static void DisplayDetails()
        {
            Console.WriteLine("----Displaying numbers in array format---");
            for (int i = 0; i < TwoDArray.GetLength(0); i++)
            {
                for (int j = 0; j < TwoDArray.GetLength(1); j++)
                {
                    Console.Write(TwoDArray[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
    
}
