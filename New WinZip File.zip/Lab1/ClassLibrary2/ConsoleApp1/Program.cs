﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp1
{ 
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeLib.Employeee[] emp = new EmployeeLib.Employeee[1];
            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new EmployeeLib.Employeee();

            }
            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("---employee details---");
                Console.WriteLine("enter your empid");
                emp[i].EmployeeId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter your name");
                emp[i].EmployeeName = Convert.ToString(Console.ReadLine());
                Console.WriteLine("enter your address");
                emp[i].Address = Convert.ToString(Console.ReadLine());
                Console.WriteLine("enter your city");
                emp[i].City = Convert.ToString(Console.ReadLine());
                Console.WriteLine("enter your dept");
                emp[i].Department = Convert.ToString(Console.ReadLine());
                Console.WriteLine("enter your salary");
                emp[i].Salary = Convert.ToInt32(Console.ReadLine());
                { 
                for (int j = 0; j < emp.Length; j++)
                    
                {
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("employee name is " + emp[j].EmployeeName + " and salary is " + emp[j].Salary);
                }
                Console.ReadKey();





            }


        }
    } }
    }

