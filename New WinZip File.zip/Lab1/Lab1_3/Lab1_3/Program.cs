﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int option;
            Console.WriteLine("press 1 \n press 2 \n press 3 \n press 4 \n press 5");
            option = Convert.ToInt32(args[0]);
            switch(option)
                {
                case 1:
                    Console.WriteLine("\nYou have entered option 1");
                    break;
                case 2:
                    Console.WriteLine("\nYou have entered option 2");
                    break;
                case 3:
                    Console.WriteLine("\nYou have entered option 3");
                    break;

                case 4:
                    Console.WriteLine("\nYou have entered option 4");
                    break;
                case 5:
                    Console.WriteLine("\nYou have entered option 5");
                    break;
                case 6:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("\n Enter valid option");
                    break;


            }
            Console.ReadLine();
        }
    }
}
