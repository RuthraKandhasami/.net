﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_4
{
  
        class program
        {
            static void Main(string[] args)
            {
                int Rollno;
                string StudentName;
                byte Age;
                char Gender;
                DateTime DoB;
                string Address;
                float Percentage;
                Console.WriteLine("-----------student details----------");
                Console.WriteLine("Rollno");
                Rollno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("StudentName");
                StudentName = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Age");
                Age = Convert.ToByte(Console.ReadLine());
                Console.WriteLine("Gender");
                Gender = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("DoB");
                DoB = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Address");
                Address = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Percentage");
                Percentage = Convert.ToInt64(Console.ReadLine());

                Console.WriteLine("___________________________");
                Console.WriteLine("displaying details");
                Console.WriteLine("Student Rollnumber is:" + Rollno);
                Console.WriteLine("Student name is:" + StudentName);
                Console.WriteLine("Student Age is:" + Age);
                Console.WriteLine("Student Gender is:" + Gender);
                Console.WriteLine("Student Date of Bieth is:" + DoB);
                Console.WriteLine("Student Address:" + Address);
                Console.WriteLine("Student Percentage is:" + Percentage);
            Console.ReadLine();

            }
        }
    }








