﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculatorlib
    {
    public class Calculator
    {
        public double Addition(double no1, double no2)
        {
            double answer;
            answer = no1 + no2;
            return answer;
        }
        public double Subtraction(double no1, double no2)
        {
            double answer;
            answer = no1 - no2;
            return answer;
        }
        public double Multiplication(double no1, double no2)
        {
            double answer;
            answer = no1 * no2;
            return answer;
        }
        public double Division(double no1, double
            no2)
        {
            double answer;
            answer = no1 / no2;
            return answer;
        }
        public double Modulus(double no1, double no2)
        {
            double answer;
            answer = no1 % no2;
            return answer;
        }


    }
}


