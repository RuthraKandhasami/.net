﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculatorlib;



namespace ConsoleApp2
{
    class Program
    { 
    static void Main(string[] args)
    {
        Console.WriteLine("~~~~~~~~~~~~calculator~~~~~~~~~~~\n");
        char option;
        do
        {
            Console.WriteLine("press 1 for Addition \n press 2 for Subtration \n press 3 for Multiplication \n press 4 for Division \n press 5 for modulus");
            int operation;
            operation = Convert.ToInt32(Console.ReadLine());
            double firstnumber;
            double secondnumber;
            double answer;
            Calculatorlib.Calculator calculator = new Calculatorlib.Calculator();
            switch (operation)
            {
                case 1:

                    Console.WriteLine("\nEnter first digit");
                    firstnumber = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("\nEnter second digit");
                    secondnumber = Convert.ToDouble(Console.ReadLine());
                    answer = calculator.Addition(firstnumber, secondnumber);
                    Console.WriteLine("\nAddition of the two number is"+answer);
                    break;
                case 2:

                    Console.WriteLine("\nEnter first digit");
                    firstnumber = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("\nEnter second digit");
                    secondnumber = Convert.ToDouble(Console.ReadLine());
                    answer = calculator.Subtraction(firstnumber, secondnumber);
                    Console.WriteLine("\nSubtraction of the two number is"+ answer);
                    break;
                case 3:

                    Console.WriteLine("\nEnter first digit");
                        firstnumber = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("\nEnter second digit");
                        secondnumber = Convert.ToDouble(Console.ReadLine());
                        answer = calculator.Multiplication(firstnumber, secondnumber);
                    Console.WriteLine("\nMultiplicatin of the two number is"+ answer);
                    break;
                case 4:

                    Console.WriteLine("\nEnter first digit");
                   firstnumber = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("\nEnter second digit");
                        secondnumber = Convert.ToDouble(Console.ReadLine());
                        answer = calculator.Division(firstnumber, secondnumber);
                    Console.WriteLine("\nDivision of the two number is"
                        + answer);
                    break;
                    case 5:

                        Console.WriteLine("\nEnter first digit");
                        firstnumber = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("\nEnter second digit");
                        secondnumber = Convert.ToDouble(Console.ReadLine());
                        answer = calculator.Modulus(firstnumber, secondnumber);
                        Console.WriteLine("\nModulus of the two number is"
                            + answer);
                        break;
                    case 6:
                    Environment.Exit(0);
                    break;
                    default:
                        Console.WriteLine("\n enter valid option");
                        break;

            }
            Console.WriteLine("\n do you want to continue? \n press 'y' or 'n' to exit");
            option = Convert.ToChar(Console.ReadLine());

        }
        while (option == 'y');
        Console.ReadLine();



    }


}
}



