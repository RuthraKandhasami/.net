﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{  
        public class ICICI : BankAccount
        {
            public override bool WithDraw(double amount)
            {


                if (balance - amount >= 0)
                {
                    balance = balance - amount;
                    return true;
                }
                else
                {
                    return false;
                }
            }


            public override bool Transfer(IBankAccount toAccount, double amount)
            {


                if (Balance - amount >= 1000)
                {
                    WithDraw(amount);
                    toAccount.Deposit(amount);

                    return true;
                }
                else
                {
                    return false;
                }
            }

            public new void AccountType(BankAccountTypeEnum bankAccountTypeEnum)
            {
                accountType = bankAccountTypeEnum;
            }
        

           
        }
    
}
