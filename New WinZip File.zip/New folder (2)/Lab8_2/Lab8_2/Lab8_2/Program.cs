﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab8_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable objHashtab = new Hashtable();
            objHashtab = GetHashtable();
            // string key = "Perimeter";
            Console.WriteLine("\nContains Key:");
            Console.WriteLine(objHashtab.ContainsKey("Perimeter"));


            bool Flag = objHashtab.ContainsKey("Area");
            if (Flag == true)
            {
                int value = (int)objHashtab["Area"];
                Console.WriteLine("Value of an Area:" + value);
            }

            Console.WriteLine("\nContains Demo:");

            objHashtab.Remove("Mortgage");
            Console.WriteLine("\nMortagage removed from Hashtable.");
            foreach (DictionaryEntry objde in objHashtab)
            {
                Console.WriteLine("key" + objde.Key + "value:" + objde.Value);
            }
            Console.ReadLine();
        }


        public static Hashtable GetHashtable()
        {
            // Create and return new Hashtable.
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;
        }

    }
}

